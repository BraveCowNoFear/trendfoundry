# TrendFoundry Sample Pack

This ZIP contains the public proof assets only. It is safe to share with potential buyers.

## Files

- public-sample.en.md / public-sample.zh-CN.md: three current opportunities with proof links.
- public-sample.en.csv / public-sample.zh-CN.csv: the same sample in spreadsheet-friendly form.
- ready-to-record-script.md: one scene-by-scene script example.
- signal-board.png: the current visual signal board.
- signal-demo.svg: an animated workflow preview showing signal-to-pack flow.
- signal-board.meta.json: data timestamp and top-item provenance for the board image.

## Upgrade

- Sample issue: USD 9 one-off.
- Weekly brief: USD 19/month.
- Custom niche: USD 49/month.

Order page: https://bravecownofear.github.io/trendfoundry/order/
GitHub request: https://github.com/BraveCowNoFear/trendfoundry/issues/new?template=order-sample-pack.yml&title=Sample%20pack%20request%3A%20
Email: rivan_Britain@outlook.com

Do not send card numbers, passwords, private IDs, wallet seeds, or payment credentials through public issues or email.
