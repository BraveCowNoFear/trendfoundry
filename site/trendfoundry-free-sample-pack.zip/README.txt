TrendFoundry Free Sample Pack

Open order-instructions.md first.

Generated from public site files. Seller-only files such as prospects.csv, outreach-board.md, latest.json, raw leads, and private order data are intentionally excluded.
